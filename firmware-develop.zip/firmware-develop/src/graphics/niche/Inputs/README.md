# NiceGraphics - Inputs

General purpose input sources, for use with NicheGraphics UIs.

By remaining independent, we can have tailored input sources with further complicating the code in ButtonThread and the canned messages module.

Depending on its role, a NicheGraphics UI may or may not want to make use of the existing input broker.
