struct PointStruct {
    int x;
    int y;
};